# ¿Cómo lo he hecho?

En primer lugar, me he descargado de [Bootstrap](https://getbootstrap.com/docs/5.1/examples/) todos los ejemplos de los temas de Bootstrap en un archivo zip, aunque finalmente sólo he extraído la carpeta `sticky-footer-navbar`. Desde la terminal, con el comando `mv`, he movido el archivo `index.html` de esta carpeta al directorio `docs` de mi repositorio local `periodismo_datos`, para posteriormente abrirlo con el comando `nano` y modificar algunos elementos. Por ejemplo, he cambiado el idioma de inglés (`“en”`) a español (`“es”`) y el título (`title`) a “Trabajo final de las pruebas de evaluación continua”. Esta modificación la he comentado debajo, empleando la siguiente estructura: `<!-- “comentario…” -- >`, 
que es la propia de los comentarios en lenguaje HTML.
Después, para aplicar el estilo a la página, he tenido que extraer del zip con los ejemplos de Bootstrap la carpeta `assets/dist/css`, donde están ubicados los archivos de estilo, `bootstrap.min.css `y `bootstrap.rtl.min.css`. A continuación, he movido estos archivos a una nueva carpeta dentro de `docs` llamada `css`. Finalmente, he abierto `index.html ` de nuevo y, en el elemento de estilo (`</style>`), he referido mis archivos `.css` con la siguiente línea: 

`link href="css/sticky-footer-navbar.css"
`

El siguiente elemento que he modificado dentro de `index.html` ha sido la del `<header>`, cuyo aspecto era así antes de mi modificación: 

```
<header>
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Fixed navbar</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" da>
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <li class=“nav-item">
            <a class="nav-link disabled">Disabled</a>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" a>
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>
</header>
```

Y ha acabado siendo así:

```
<header>
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Pablo Gutiérrez Sánchez</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" da>
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href=“#”>Actividad 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href=“#">Actividad 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Actividad 3</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href=“#">Actividad 4</a>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" a>
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>
</header>
```

Como puede apreciarse, he cambiado el nombre de los 3 apartados preexistentes (`Home` por `Inicio`, `Link` por `Actividad 1` y `Disabled` por `Actividad 2`) y he añadido otros  dos nuevos —`Actividad 3` y `Actividad 4`— copiando el código de los anteriores y asignándoles otro nombre. En el caso del apartado `Disabled`, he tenido que cambiar también la línea: 

`<a class="nav-link disabled”…` 

por 

`<a class=nav-link”… `

Sin embargo, ese mismo código lo he empleado para la *Actividad 3*, justamente porque me interesaba que apareciera como deshabilitada (puesto que no realicé esa práctica). 

Todo lo anterior me ha servido para que los apartados se llamaran como yo quería, pero aún quedaba enlazar dichos apartados con el contenido de mis ejercicios. Para eso, puesto que los archivos de mis ejercicios están originalmente en formato `markdown`, he tenido que hacer un paso previo. Con el comando `pandoc`, dentro de la terminal, he convertido los ejercicios de mi repositorio de `markdown` a `html`, llamando a los archivos resultantes de la siguiente forma: `ejercicio_base.html.` Paralelamente, he creado dos archivos, `cabecera.html` y `pie.html`, a partir de las primeras y últimas líneas (excluyendo la parte dedicada al contenido propiamente dicho de la página), respectivamente, del archivo `index.html`. Con estos dos archivos y la plantilla del ejercicio en cuestión, unidos los tres a través del comando `cat`, he obtenido los documentos que finalmente enlazaré en mi página. He llamado a estos documentos `ejercicio_1.html`, `ejercicio_2.html` y `ejercicio_4.html`. Finalmente, he enlazado estos tres archivos a su respectivo apartados, quedando así el elemento `header` de mi `index.html`:

```
<header>
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Pablo Gutiérrez Sánchez</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" da>
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Ejercicio_1.html">Actividad 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Ejercicio_2.html">Actividad 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled">Actividad 3</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Ejercicio_4.html">Actividad 4</a>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" a>
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>
</header>
```


Estos mismos cambios los he aplicado también en cada uno de los documentos `.html` de mi directorio `docs`, para que también desde ellos pueda accederse a los demás ejercicios y no redirijan a sí mismos, como ocurriría si dejara: `href=“#”`. 
Después, cuando he terminado de escribir la metolodogía en un archivo de formato markdown, lo he enlazado en los documentos `.html `siguiendo el mismo proceso que con los ejercicios. En este caso, he creado un nuevo apartado dentro del elemento `Header`:
         
          <li class="nav-item">
            <a class="nav-link" href="Metodología.html">Metodología</a>
          </li>

Estas tres líneas las he replicado en todos los documentos `.html` de mi carpeta `docs`. 
Ahora sólo falta que los cambios, hechos en mi repositorio local, se reflejan también en mi repositorio remoto en `GitHub`. Para ello, desde dentro de mi carpeta (`periodismo_datos`), en la terminal, ejecuto el comando `git add`: 

`git add docs`

Después, con `git commit -m “8-dic”`, comento el cambio, registrando simplemente la fecha en que lo estoy haciendo. El último paso es hacer `git push` y, entonces, estará todo en mi repositorio de `GitHub`. 

Nota: para que la pagina se sirva desde `GitHub`, previamente hay que ir a `Settings` dentro de mi repositorio y luego al apartado `Pages`. En `Source`, le he dicho a `GitHub` que para la página beba de mi carpeta `Docs`. Para que el cambio se haga efectiva, le he dado a `Save`. 






