_Comandos_
* "nano": editor de texto
* "cp + (origen) + (destino)": copiar
* "whoami": quien soy yo
