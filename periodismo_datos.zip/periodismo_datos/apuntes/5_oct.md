## Comandos
* "ls": listar los archivos de un directorio.
* "pwd": print working directory.
* "env": entorno.
* "cat": concatenar.
* "mkdir": crear carpeta
* "cd": cambiar directorio
* "man": manual
* "file": qué tipo de archivo es
* "WC": 
* "head": muestra (por defecto) las 10 primeras líneas del archivo.
* "tail": muestra la cola del archivo

_comando + opciones + argumentos_
* "ls -a": listar los archivos ocultos
* "ls -la": 

## Operadores
* ">": enviar el contenido de un comando (que normalemente sale por la pantalla) a un archivo.
* ">>": envía el contnendio del comando al final del archivo (sin pisar/sobreescribir lo anterior)

## Cómo crear un archivo de texto
* "echo «loquesea» > «nombredelarchivo.txt»"
* 


