## Tipos de datos numéricos
* Integer: números enteros, sin decimales.
* Decimal: números con decimales pero pcoso decimales y siempre el mismo número de decimales. 
* Float or double: número con decimales pero que pueden tener muchos deciamles y/o variables en su longitud. 
* Date or datetime. 
* Period
