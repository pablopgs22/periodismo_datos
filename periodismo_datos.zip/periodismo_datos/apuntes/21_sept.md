## Tipos de datos
* Numeros 
* Fecha: YYYY-MM-DD
* Booleanos: _0/1_ / _True/False_
* Strings: cadenas de caracteres. Es lo que podríamos llamar lenguaje natural. 
