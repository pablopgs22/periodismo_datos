# Clase 14 septiembre
La arquitectura de funcionamiento de un ordenador es de cliente-servidor. 

__LOCAL HOST__: (es el dominio de mi ordenador): 127001 --- Cada ordenador es un local host.

__DNS__: sistema de nombres de dominios; hace la conversión entre una IP y un dominio. 

Todo directorio web tiene que tener un documento __INDEX.html__

A través de __APPS__ accedemos a __GUI__. Sin embargo, para el periodismo de datos, es prefeirble el uso de la terminal (__TER__), que nos permite usar el __GUI__. Aplicaciones de línea de comandos _VS_ Aplicaciones de visualización gráfica.

La terminal es una interfaz de línea de comandos.

Una __API__ es la forma en la que un software te dice cómo tienes que comunicarte con él. En el mundo web, la __API__ principal es __HTTP__; en el mundo de los sistemas operatvos, __POSIX__ es una de las __APIs__ que está, por ejemplo, detrás de Mac o de Linux. 

__CSV__: comma-separated values ------- __TSV__: tabulate-separated values (valores separados por tabulador).
