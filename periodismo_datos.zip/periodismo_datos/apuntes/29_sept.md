# Apuntes
* STDIN: entrada estándar
* STDOUT: salida estándar
* STDERR: error estándar
* ">": mandar salida esándar a un achivo local. 
* "|": pasa la salida de un comando como entrada de datos del comando siguiente. 
* "pwd": imprime el directorio de trabajo.
* "ls": sirve para listar los archis y directorios del directorio donde estás. 
* "cd": para cambiar de directorio.

## Ley de Moore
El número de transistores se duplica cada cuatro meses

Para ordenarnos mentalmente, cuando est
