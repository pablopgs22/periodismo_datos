# Cómo hacer zip de una carpeta
Con el comando: "zip -r "nombre_del_zip.zip" "nombre_de_la_carpeta_a_la_que_quiero_hacer_zip"
Meteré este zip en la carpeta de mi git local, para subirlo a mi git remoto, en GitHub. 

### Enlace de ayuda para HTML: 
https://developer.mozilla.org/en-US/

El archivo de configuración de la terminal de Mac es .zshrc

