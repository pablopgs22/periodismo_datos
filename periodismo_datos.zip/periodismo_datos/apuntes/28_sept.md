Para enlazar un archivo en relación con otro (lo que llamamos una ruta relativa), ponemos «ahref="nombre del archivo al que se vincula"»
Por ejemplo, si una noticia está en el mismo directorio que otra -llamémosla "noticia"- (por ejemplo, porqeue es del mismo día), en lugar de poner la ruta absoluta (https://theguardian.com/us-news/sept/27/noticia2), ponemos simplemente «ahref="noticia1"»

pwd: print working directory
